/*
 * jversion.h
 *
 * Copyright (C) 1991-1998, Thomas G. Lane.
 * This file is part of the Independent JPEG Group's software.
 * For conditions of distribution and use, see the accompanying README file.
 *
 * This file contains software version identification.
 */


#define JVERSION	"6b  27-Mar-1998"

#define JCOPYRIGHT	"Copyright (C) 1998, Thomas G. Lane"
