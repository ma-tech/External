/* BEGIN_HEADER                                              Java TreeView
 *
 * $Author: alokito $
 * $RCSfile: KnnViewFrame.java,v $
 * $Revision: 1.13 $
 * $Date: 2006/03/19 23:20:57 $
 * $Name:  $
 *
 * This file is part of Java TreeView
 * Copyright (C) 2001-2003 Alok Saldanha, All Rights Reserved. Modified by Alex Segal 2004/08/13. Modifications Copyright (C) Lawrence Berkeley Lab.
 *
 * This software is provided under the GNU GPL Version 2. In particular, 
 *
 * 1) If you modify a source file, make a comment in it containing your name and the date.
 * 2) If you distribute a modified version, you must do it under the GPL 2.
 * 3) Developers are encouraged but not required to notify the Java TreeView maintainers at alok@genome.stanford.edu when they make a useful addition. It would be nice if significant contributions could be merged into the main distribution.
 *
 * A full copy of the license can be found in gpl.txt or online at
 * http://www.gnu.org/licenses/gpl.txt
 *
 * END_HEADER 
 */
package edu.stanford.genetics.treeview;


import java.util.Observer;

import edu.stanford.genetics.treeview.app.KnnViewApp;
import edu.stanford.genetics.treeview.dendroview.DendroView;
import edu.stanford.genetics.treeview.dendroview.KnnDendroView;
import edu.stanford.genetics.treeview.model.KnnModel;
import edu.stanford.genetics.treeview.model.TVModel;


public class KnnViewFrame extends TreeViewFrame implements Observer
{
	public String getAppName() {
		return appName;
	}
	private static String appName = "Java KmeansView";
	
	public KnnViewFrame(KnnViewApp treeview)
	{
		super(treeview, appName);
	}
	
	/**
	* This is the workhorse. It must create a new DataModel of the
	* file, and then setup the running window.
	*/
	public void loadFileSet(FileSet fileSet)  throws LoadException {
		//First, need to detect type of model to make...
		if (fileSet.getKag().equals("") && fileSet.getKgg().equals("")) {
			TVModel tvModel = new TVModel();
			tvModel.loadNew(fileSet);
			tvModel.setFrame(this);
			setDataModel(tvModel);
		} else {
			KnnModel knnModel = new KnnModel();
			knnModel.loadNew(fileSet);
			knnModel.setFrame(this);
			setDataModel(knnModel);
		}
	}
	
	 protected void setupRunning() {
		 DendroView dv;
		 try {
		 	KnnModel model = (KnnModel) getDataModel();
			dv = new KnnDendroView(model, this);
		 } catch (ClassCastException e) {
			dv = new DendroView(getDataModel(), this);
		 }
		 running = dv;
	 }	
}

