/*
 *  BEGIN_HEADER                                              Java TreeView
 *
 *  $Author: alokito $
 *  $RCSfile: ProgressTrackable.java,v $
 *  $Revision: 1.4 $
 *  $Date: 2005/02/07 03:32:12 $
 *  $Name:  $
 *
 *  This file is part of Java TreeView
 *  Copyright (C) 2001-2003 Alok Saldanha, All Rights Reserved. Modified by Alex Segal 2004/08/13. Modifications Copyright (C) Lawrence Berkeley Lab.
 *
 *  This software is provided under the GNU GPL Version 2. In particular,
 *
 *  1) If you modify a source file, make a comment in it containing your name and the date.
 *  2) If you distribute a modified version, you must do it under the GPL 2.
 *  3) Developers are encouraged but not required to notify the Java TreeView maintainers at alok@genome.stanford.edu when they make a useful addition. It would be nice if significant contributions could be merged into the main distribution.
 *
 *  A full copy of the license can be found in gpl.txt or online at
 *  http://www.gnu.org/licenses/gpl.txt
 *
 *  END_HEADER
 */
 
 package edu.stanford.genetics.treeview.model;

/**
 * The idea here is that objects which implement this interface can have their progress depicted
 *by a progress bar. You could define a specialized timer class which kept pointers to a
 *ProgressTrackable and a JProgressBar, and every few hundred milliseconds made sure that the
 *JProgressBar reflected the ProgressTrackable. Asynchronously, you could have another thread change
 *the values in the ProgressTrackable.
 *
 * @author     aloksaldanha
 */
interface ProgressTrackable {

	/**
	* The length holds the length in bytes of the input stream, or -1 if not known.
	*/
	/** Setter for length */
	public void setLength(int length);
	/** Getter for length */
	public int getLength();
	
	
	/**
	* The value holds the current position, which will be between 0 and length, if length is >= 0.
	*/
	
	/** Setter for value */
	public void setValue(int value);
	/** Getter for value */
	public int getValue();
	/** increments value */
	public void incrValue(int i);
	
}
