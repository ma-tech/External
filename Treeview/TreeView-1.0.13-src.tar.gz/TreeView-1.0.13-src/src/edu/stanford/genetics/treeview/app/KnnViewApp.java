/* BEGIN_HEADER                                              Java TreeView
 *
 * $Author: alokito $
 * $RCSfile: KnnViewApp.java,v $
 * $Revision: 1.10 $
 * $Date: 2005/03/06 01:51:42 $
 * $Name:  $
 *
 * This file is part of Java TreeView
 * Copyright (C) 2001-2003 Alok Saldanha, All Rights Reserved. Modified by Alex Segal 2004/08/13. Modifications Copyright (C) Lawrence Berkeley Lab.
 *
 * This software is provided under the GNU GPL Version 2. In particular,
 *
 * 1) If you modify a source file, make a comment in it containing your name and the date.
 * 2) If you distribute a modified version, you must do it under the GPL 2.
 * 3) Developers are encouraged but not required to notify the Java TreeView maintainers at alok@genome.stanford.edu when they make a useful addition. It would be nice if significant contributions could be merged into the main distribution.
 *
 * A full copy of the license can be found in gpl.txt or online at
 * http://www.gnu.org/licenses/gpl.txt
 *
 * END_HEADER */
package edu.stanford.genetics.treeview.app;
import edu.stanford.genetics.treeview.*;

/**
 *  This class defines the knnview application. The actual Gui handling of a given
 *  window is currently done by KnnViewFrame, which represents a single document.
 *
 * The main difference between the apps is which <code>ViewFrame</code> they use. <code>KnnViewApp</code> uses <code>KnnViewFrame</code>.
 *
 * @author     Alok Saldanha <alok@genome.stanford.edu>
 * @version $Revision: 1.10 $ $Date: 2005/03/06 01:51:42 $
 */
public class KnnViewApp extends TreeViewApp {

	/**  Constructor for the KnnViewApp object */
	public KnnViewApp() {
		super();
	}


	/**  Creates a KnnViewFrame window  */
	public ViewFrame openNew() {
		// setup toplevel
		KnnViewFrame tvFrame  =
				new KnnViewFrame(this);
		tvFrame.addWindowListener(this);
		return tvFrame;
	}


	/**
	 *  Creates a new window with the given fileset loaded in it.
	 *
	 * @param  fileSet            FileSet from which to get data
	 * @exception  LoadException  If there is a problem loading the fileset, the window is closed and the exception is passed on to the caller.
	 */
	public ViewFrame openNew(FileSet fileSet) throws LoadException {
		// setup toplevel
		KnnViewFrame tvFrame  =
				new KnnViewFrame(this);
		try {
			tvFrame.loadFileSet(fileSet);
			tvFrame.setLoaded(true);
		} catch (LoadException e) {
			tvFrame.dispose();
			throw e;
		}

		tvFrame.addWindowListener(this);
		return tvFrame;
	}


	/**
	 *  Starts KnnView application with an empty window.
	 *
	 * @param  astring  standard argument string.
	 */
	public static void main(String astring[]) {
		KnnViewApp treeView  = new KnnViewApp();
		// setup toplevel
		treeView.standardStartup(astring);
	}
}

