/* BEGIN_HEADER                                              Java TreeView
 *
 * $Author: alokito $
 * $RCSfile: LinkedViewApp.java,v $
 * $Revision: 1.18 $
 * $Date: 2005/12/18 02:15:28 $
 * $Name:  $
 *
 * This file is part of Java TreeView
 * Copyright (C) 2001-2003 Alok Saldanha, All Rights Reserved. Modified by Alex Segal 2004/08/13. Modifications Copyright (C) Lawrence Berkeley Lab.
 *
 * This software is provided under the GNU GPL Version 2. In particular,
 *
 * 1) If you modify a source file, make a comment in it containing your name and the date.
 * 2) If you distribute a modified version, you must do it under the GPL 2.
 * 3) Developers are encouraged but not required to notify the Java TreeView maintainers at alok@genome.stanford.edu when they make a useful addition. It would be nice if significant contributions could be merged into the main distribution.
 *
 * A full copy of the license can be found in gpl.txt or online at
 * http://www.gnu.org/licenses/gpl.txt
 *
 * END_HEADER */
package edu.stanford.genetics.treeview.app;
import edu.stanford.genetics.treeview.*;
import edu.stanford.genetics.treeview.dendroview.DendrogramFactory;


/**
 *  Main class of LinkedView application. 
 * Mostly manages windows, and communication between windows, as well as communication between them.
 *
 * The main difference between the apps is which <code>ViewFrame</code> they use. <code>LinkedViewApp</code> uses <code>LinkedViewFrame</code>.
 * @author     Alok Saldanha <alok@genome.stanford.edu>
 * @version    $Revision: 1.18 $ $Date: 2005/12/18 02:15:28 $
 */
public class LinkedViewApp extends TreeViewApp {
	/**  Constructor for the LinkedViewApp object */
	private static final String [] plugins =
		new String [] {
			"edu.stanford.genetics.treeview.dendroview.DendrogramFactory",
			"edu.stanford.genetics.treeview.dendroview.AlignmentFactory",
			"edu.stanford.genetics.treeview.scatterview.ScatterplotFactory",
			"edu.stanford.genetics.treeview.treeanno.GeneAnnoFactory",
			"edu.stanford.genetics.treeview.treeanno.ArrayAnnoFactory",
			"edu.stanford.genetics.treeview.karyoview.KaryoscopeFactory"
	};
	public LinkedViewApp() {
		super();
		// scan for plugins...
		for (int i = 0; i < plugins.length; i++) {
			try {
				Class.forName(plugins[i]);
			} catch (ClassNotFoundException e) {
        			LogBuffer.println("Could not load plugins");
			}
		}
		assignPresetsNodes();
	}
	/**
	* Constructor for the TreeViewApp object
	* takes configuration from the passed in XmlConfig.
	*/
	public LinkedViewApp(XmlConfig xmlConfig) {
		super(xmlConfig);
	}
	/* inherit description */
	public ViewFrame openNew() {
		// setup toplevel
		LinkedViewFrame tvFrame  =
				new LinkedViewFrame(this);
		tvFrame.addWindowListener(this);
		return tvFrame;
	}


	/* inherit description */
	public ViewFrame openNew(FileSet fileSet) throws LoadException {
		// setup toplevel
		LinkedViewFrame tvFrame  =
				new LinkedViewFrame(this);
		try {
			tvFrame.loadFileSet(fileSet);
			tvFrame.setLoaded(true);
		} catch (LoadException e) {
			tvFrame.dispose();
			throw e;
		}

		tvFrame.addWindowListener(this);
		return tvFrame;
	}

	/**
	* same as above, but doesn't open a loading window (damn deadlocks!)
	*/
	public ViewFrame openNewNW(FileSet fileSet) throws LoadException {
		// setup toplevel
		LinkedViewFrame tvFrame  = new LinkedViewFrame(this);
		if (fileSet != null) {
			try {
				tvFrame.loadFileSetNW(fileSet);
				tvFrame.setLoaded(true);
			} catch (LoadException e) {
				tvFrame.dispose();
				throw e;
			}
		}
		tvFrame.addWindowListener(this);
		return tvFrame;
	}


	/* inherit description */
	public static void main(String astring[]) {

		LinkedViewApp statView  = new LinkedViewApp();
		// setup toplevel
		statView.standardStartup(astring);
	}


	/* inherit description */
	public static String getVersionTag() {
		return TreeViewApp.versionTag;
	}
}

