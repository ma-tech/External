/* BEGIN_HEADER                                              Java TreeView
 *
 * $Author: alokito $
 * $RCSfile: TVModelLoader.java,v $f
 * $Revision: 1.22 $
 * $Date: 2005/12/05 05:27:53 $
 * $Name:  $
 *
 * This file is part of Java TreeView
 * Copyright (C) 2001-2003 Alok Saldanha, All Rights Reserved. Modified by Alex Segal 2004/08/13. Modifications Copyright (C) Lawrence Berkeley Lab.
 *
 * This software is provided under the GNU GPL Version 2. In particular, 
 *
 * 1) If you modify a source file, make a comment in it containing your name and the date.
 * 2) If you distribute a modified version, you must do it under the GPL 2.
 * 3) Developers are encouraged but not required to notify the Java TreeView maintainers at alok@genome.stanford.edu when they make a useful addition. It would be nice if significant contributions could be merged into the main distribution.
 *
 * A full copy of the license can be found in gpl.txt or online at
 * http://www.gnu.org/licenses/gpl.txt
 *
 * END_HEADER 
 */
package edu.stanford.genetics.treeview.model;

import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.*;
import java.util.Vector;

import javax.swing.*;

import edu.stanford.genetics.treeview.*;

public class TVModelLoader implements ProgressTrackable {

	// these internal variables are needed by this class only
	/** frame to block */
	Frame parent;
	/** model to load into */
	TVModel targetModel;
	
	javax.swing.Timer loadTimer;
	LoadProgress2 loadProgress;
	
	// the following is for the communication between the timer thread and the worker thread.
	
	/** We hold fatal exceptions, for access by a reporting thread */
	LoadException exception = null;
	/** Setter for exception */
	public void setException(LoadException exception) {
		this.exception = exception;
	}
	/** Getter for exception */
	public LoadException getException() {
		return exception;
	}
	
	
	/** did we encounter a problem in parsing? */
	boolean hadProblem = false;
	/** Setter for hadProblem */
	public void setHadProblem(boolean hadProblem) {
		this.hadProblem = hadProblem;
	}
	/** Getter for hadProblem */
	public boolean getHadProblem() {
		return hadProblem;
	}
	
	/**
	* This variable holds the length in bytes of the input stream, or -1 if not known.
	*/
	int length = -1;
	/** Setter for length */
	public void setLength(int length) {
		this.length = length;
		loadProgress.setLength(length);
	}
	/** Getter for length */
	public int getLength() {
		return length;
	}
	
	
	/**
	* This variable holds the current position, which will be between 0 and length, if length is >= 0.
	*/
	int value;
	/** Setter for value */
	public void setValue(int value) {
		this.value = value;
	}
	/** Getter for value */
	public int getValue() {
		return value;
	}
	public void incrValue(int i) {
		value += i;
	}
	
	boolean finished = false;  // this is set when thread forced to stop.
	/** Setter for finished */
	public void setFinished(boolean finished) {
		this.finished = finished;
		parser.setCancelled(finished);
	}
	/** Getter for finished */
	public boolean getFinished() {
		return finished;
	}
	
	public int phaseValue;
	/** Setter for phaseValue */
	public void setPhaseValue(int phaseValue) {
		this.phaseValue = phaseValue;
	}
	/** Getter for phaseValue */
	public int getPhaseValue() {
		return phaseValue;
	}
	
	public int phaseLength = -1;
	/** Setter for phaseLength */
	public void setPhaseLength(int phaseLength) {
		loadProgress.setPhaseLength(phaseLength);
		this.phaseLength = phaseLength;
	}
	/** Getter for phaseLength */
	public int getPhaseLength() {
		return phaseLength;
	}
	
	public String phaseText;
	/** Setter for phaseText */
	public void setPhaseText(String phaseText) {
		this.phaseText = phaseText;
	}
	/** Getter for phaseText */
	public String getPhaseText() {
		return phaseText;
	}
	
	private FlatFileParser parser = new FlatFileParser();
	
	class TimerListener implements ActionListener { // manages the FileLoader
		// this method is invoked every few hundred ms
		public void actionPerformed(ActionEvent evt) {
			loadProgress.setValue(getValue());
			loadProgress.setPhaseValue(getPhaseValue());
			loadProgress.setPhaseText(getPhaseText());
			if (loadProgress.getCanceled() || getFinished()) {
				setFinished(true);
				loadTimer.stop();
				if (getHadProblem() == false) { 
					loadProgress.setVisible(false);
				} else {
					loadProgress.setButtonText("Dismiss");
					Toolkit.getDefaultToolkit().beep();
					loadProgress.getToolkit().beep();
				}
			}
		}
	}
	
	public TVModelLoader(TVModel targetModel) {
		this(targetModel, targetModel.getFrame());
	}
	
	public TVModelLoader(TVModel targetModel, Frame parent) {
		this.parent = parent;
		this.targetModel = targetModel;
		loadTimer = new javax.swing.Timer(200, new TimerListener());
		loadTimer.stop();
	}
	
	public void loadInto() throws LoadException {
		loadProgress = new LoadProgress2("loading "+targetModel.getFileSet().getRoot()+"...", parent);
		final SwingWorker worker = new SwingWorker() {
			public Object construct() {
				run();
				return null;
			}
		};
		parser.setCancelled(false);
		// start up the worker thread
		worker.start();
		loadTimer.start();
		// show a modal dialog, should block until loading done...
		loadProgress.setIndeterminate(true);
		loadProgress.pack();
		loadProgress.setVisible(true);
		// System.out.println("loadNew 6, ex: " + fileLoader.getException());
		if (getException() != null) {
			throw getException();
		}
	}
	/**
	* Don't open a window.
	*/
	public void loadIntoNW() throws LoadException {
		loadProgress = new LoadProgress2("loading "+targetModel.getFileSet().getRoot()+"...", null);
		run();
		if (getException() != null) {
			throw getException();
		}
	}
	
	public static String [] phases = new String [] {"Loading Cdt",
	"Parsing Cdt", "Loading ATR", "Parsing ATR", "Loading GTR", "Parsing GTR", "Loading Document Config", "Finished"};
	private void setPhase(int i) {
		setPhaseValue(i+1);
		setPhaseText(phases[i]);
	}
	
	// this routine manages phase bar stuff. 
	// progress bar stuff is set within the 
	// table loading and various parsing routines.
	private void run() {
		try {
			FileSet fileSet = targetModel.getFileSet();
			setPhaseLength(phases.length);
			setPhase(0);
			println("loading " + fileSet.getCdt() + " ... ");
			try {
				parser.setResource(fileSet.getCdt());
				parser.setProgressTrackable(this);
				Vector tempTable = parser.loadIntoTable();
				setPhase(1);
				parseCDT(tempTable);
			} catch (LoadException e) {
				throw e;
			} catch (Exception e) {
				// this should never happen!
				LogBuffer.println("TVModel.ResourceLoader.run() : while parsing cdt got error " + e.getMessage());
				e.printStackTrace();
				throw new LoadException("Error Parsing CDT: " + e, LoadException.CDTPARSE);
			}
			
			setPhase(2);
			if (targetModel.getArrayHeaderInfo().getIndex("AID") != -1) {
				println("parsing atr");
				try {
					parser.setResource(fileSet.getAtr());
					parser.setProgressTrackable(this);
					Vector tempTable = parser.loadIntoTable();
					setPhase(3);
					parseATR(tempTable);
					targetModel.hashAIDs();
					targetModel.hashATRs();
					targetModel.aidFound(true);
				} catch (Exception e) {
					println("error parsing ATR: " + e.getMessage());
					e.printStackTrace();
					println("ignoring array tree.");
					hadProblem = true;
					targetModel.aidFound(false);
				}
			} else {
				targetModel.aidFound(false);
			}
			
			setPhase(4);
			if (targetModel.getGeneHeaderInfo().getIndex("GID") != -1) {
				println("parsing gtr");
				try {
					parser.setResource(fileSet.getGtr());
					parser.setProgressTrackable(this);
					Vector tempTable = parser.loadIntoTable();
					setPhase(5);
					parseGTR(tempTable);
					targetModel.hashGIDs();
					targetModel.hashGTRs();
					targetModel.gidFound(true);
				} catch (Exception e) {
					println("error parsing GTR: " + e.getMessage());
					println("ignoring gene tree.");
					hadProblem = true;
					targetModel.gidFound(false);
				}
			} else {
				targetModel.gidFound(false);
			}
			setPhase(6);

			try {
				println("parsing jtv config file");
				XmlConfig documentConfig = new XmlConfig(targetModel.getFileSet().getJtv(),
				"DocumentConfig");
				targetModel.setDocumentConfig(documentConfig);
			} catch (Exception e) {
				targetModel.setDocumentConfig(null);
				println("Got exception " + e);
				setHadProblem(true);
			}
			setPhase(7);
			if (getException() == null) {
				/*	
				if (!fileLoader.getCompleted()) {
					throw new LoadException("Parse not Completed", LoadException.INTPARSE);
				}
				//System.out.println("f had no exceptoin set");
				*/
			} else {
				throw getException();
			}
			//	ActionEvent(this, 0, "none",0);
		} catch (java.lang.OutOfMemoryError ex) {
							JPanel temp = new JPanel();
							temp. add(new JLabel("Out of memory, allocate more RAM"));
							temp. add(new JLabel("see Chapter 3 of Help->Documentation... for Out of Memory"));
							JOptionPane.showMessageDialog(parent,  temp);
		} catch (LoadException e) {
			setException(e);
			println("error parsing File: " + e.getMessage());
			println("parse cannot succeed. please fix.");
			hadProblem = true;
		}
		setFinished(true);
	}
	
	
	/**
	* This routine expects a vector of strings
	* representing the tab-delimitted text
	*/
	private void  parseCDT(Vector tempVector) throws LoadException {
		// find eweightLine, ngene, nexpr
		findCdtDimensions(tempVector);
		loadArrayAnnotation(tempVector);
		loadGeneAnnotation(tempVector);
		loadCdtData(tempVector);
	}
	
	
	// finds ngene, nexpr, nArrayPrefix, nGenePrefix
	// 
	protected void findCdtDimensions(Vector tempVector)  {
		println("Finding Cdt Dimensions");
		
		String [] firstLine =(String []) tempVector.elementAt(0);
		int gweightCol = -1;
		for (int i =0; i < firstLine.length; i++) {
			String s = firstLine[i];
			if (s == null) {
				System.out.println("Got null header, setting to ''");
				s = "";
			}
			if (s.equalsIgnoreCase("GWEIGHT")) {
				gweightCol = i;
				break;
			}
		}
		
		if (gweightCol == -1) {
			if (firstLine[0].equalsIgnoreCase("GID")) {
				nGenePrefix = 3;
			} else {
				nGenePrefix = 2;
			}
		} else {
			nGenePrefix = gweightCol + 1;
		}
		
		nExpr = firstLine.length - nGenePrefix;
		
		int eweightRow = -1;
		for (int i = 0; i < tempVector.size(); i++) {
			String s = ((String []) tempVector.elementAt(i))[0];
			if (s.equalsIgnoreCase("EWEIGHT")) {
				eweightRow = i;
				break;
			}
		}
		if (eweightRow == -1) {
			String [] secondLine =(String []) tempVector.elementAt(1);
			if (secondLine[0].equalsIgnoreCase("AID")) {
				nExprPrefix = 2;
			} else {
				nExprPrefix = 1;
			}
		} else {
			nExprPrefix = eweightRow + 1;
		}
		
		nGene = tempVector.size() - nExprPrefix;
	}
	
	protected void loadArrayAnnotation(Vector tempVector) {
		String [] arrayPrefix = new String[nExprPrefix];
		String [][] aHeaders = new String [nExpr][nExprPrefix];
		
		for (int i = 0; i < nExprPrefix; i++) {
			String [] tokens = (String []) tempVector.elementAt(i);
//			System.out.println("row "  + i + " got vector " + tokens);
			arrayPrefix[i] = tokens[0];
			for (int j = 0; j < nExpr; j++) {
//				System.out.print(", "  + tokens[j+nGenePrefix]);
				aHeaders[j][i] = tokens[j + nGenePrefix];
			}
				System.out.println(" ");
		}
		targetModel.setArrayPrefix(arrayPrefix);
		targetModel.setArrayHeaders(aHeaders);
	}
	
	protected void loadGeneAnnotation(Vector tempVector) {
		String [] genePrefix = new String[nGenePrefix];
		String [][] gHeaders = new String [nGene][nGenePrefix];
		
		String [] firstLine = (String []) tempVector.elementAt(0);
		for (int i = 0; i < nGenePrefix; i++) {
			genePrefix[i] = firstLine[i];
		}
		setLength(nGene);
		for (int i = 0; i < nGene; i++) {
			setValue(i);
			String [] tokens = (String []) tempVector.elementAt(i + nExprPrefix);
			for (int j = 0; j < nGenePrefix; j++) {
				gHeaders[i][j] = tokens[j];
			}
		}
		targetModel.setGenePrefix(genePrefix);
		targetModel.setGeneHeaders(gHeaders);
	}
	
	private void loadCdtData(Vector tempVector) {
		println("Parsing strings into doubles...");
		setLength(nGene);
		double [] exprData = new double[nGene * nExpr];
		
		for (int gene = 0 ; gene < nGene; gene++) {
			if (getFinished() == true) break; // we're cancelled
			setValue(gene);
			String [] tokens = (String []) tempVector.elementAt(gene+nExprPrefix);
			// removes this row...
			tempVector.setElementAt(null,gene+nExprPrefix);
			int found = tokens.length - nGenePrefix;
			if (found != nExpr) {
				hadProblem = true;
				String err = "Wrong number of fields for gene " + tokens[0] + 
				" row " + (gene + nExprPrefix) +
				" Expected " + nExpr + ", found " + found;
				println(err);
				err = "Line contains:";
				err += " " + tokens[0];
				for (int i = 1; i < tokens.length; i++) {
					err += ", " + tokens[i];
				}
				println(err);
				if (found > nExpr) {
					println("ignoring extra values");
					found = nExpr;
				} else if (found < nExpr) {
					println("treating missing values as No Data..");
					for (int i = found; i < nExpr; i++) {
						exprData[gene*nExpr + i] = DataModel.NODATA;
					}
				}
			}
			for (int expr = 0; expr < found; expr++) {
				try {
					exprData[gene*nExpr + expr] = makeDouble(tokens[expr+nGenePrefix]);
				} catch (Exception e) {
					setHadProblem(true);
					println(e.getMessage());
					println("Treating value as not found for gene " + gene + " experiment " + expr);
					exprData[gene * nExpr + expr] = DataModel.NODATA;
				}
			}
		}
		targetModel.setExprData(exprData);
	}
	private int doublesMade = 0;
	private double makeDouble(String s) throws NumberFormatException {
		if (doublesMade++ % 100000 == 0) {
//			System.err.println("Made " + doublesMade + " doubles, calling GC...");
//			rt.gc();
		}
		if (s == null) {
			return DataModel.NODATA;
		} else {
			Double tmp = new Double(s);
			return tmp.doubleValue();
		}
	}
	
	
	private void parseATR(Vector tempVector) throws LoadException {
		String [] firstRow = (String []) tempVector.firstElement();
		if ( // decide if this is not an extended file..
			(firstRow.length == 4)// is the length classic?
		&& (firstRow[0].equalsIgnoreCase("NODEID") == false) // does it begin with a non-canonical upper left?
		) { // okay, need to assign headers...
			targetModel.setAtrPrefix(new String [] {"NODEID", "LEFT", "RIGHT", "CORRELATION"});
			String [][] atrHeaders = new String[tempVector.size()][];
			for (int i =0; i < atrHeaders.length; i++) {
				atrHeaders[i] = (String []) tempVector.elementAt(i);
			}
			targetModel.setAtrHeaders(atrHeaders);
		} else {// first row of tempVector is actual header names...
			targetModel.setAtrPrefix(firstRow);

			String [][] atrHeaders = new String[tempVector.size()-1][];
			for (int i =0; i < atrHeaders.length; i++) {
				atrHeaders[i] = (String []) tempVector.elementAt(i+1);
			}
			targetModel.setAtrHeaders(atrHeaders);
		}
	}
	
	private void parseGTR(Vector tempVector) throws LoadException {
		String [] firstRow = (String []) tempVector.firstElement();
		if ( // decide if this is not an extended file..
			(firstRow.length == 4)// is the length classic?
		&& (firstRow[0].equalsIgnoreCase("NODEID") == false) // does it begin with a non-canonical upper left?
		) { // okay, need to assign headers...
			targetModel.setGtrPrefix(new String [] {"NODEID", "LEFT", "RIGHT", "CORRELATION"});
			String [][] gtrHeaders = new String[tempVector.size()][];
			for (int i =0; i < gtrHeaders.length; i++) {
				gtrHeaders[i] = (String []) tempVector.elementAt(i);
			}
			targetModel.setGtrHeaders(gtrHeaders);
		} else {// first row of tempVector is actual header names...
			targetModel.setGtrPrefix(firstRow);

			String [][] gtrHeaders = new String[tempVector.size()-1][];
			for (int i =0; i < gtrHeaders.length; i++) {
				gtrHeaders[i] = (String []) tempVector.elementAt(i+1);
			}
			targetModel.setGtrHeaders(gtrHeaders);
		}
		/*/ test out the GtrHeaders...
		HeaderInfo gtrHeaders = targetModel.getGtrHeaderInfo();
		for (int i = 0; i < gtrHeaders.getNumHeaders(); i++) {
			String nodeId = gtrHeaders.getHeader(i, "NODEID");
			String leftId = gtrHeaders.getHeader(i, "LEFT");
			String rightId = gtrHeaders.getHeader(i, "RIGHT");
			String corr = gtrHeaders.getHeader(i, "CORRELATION");
			System.out.println("node " + nodeId + " has left ID " + leftId + ", right id " + rightId + "corre " + corr);
		}
		*/
	}
	
		 /*
	private int parseNodes(Vector nvec, Vector source, int ptype) {
		setLength(source.size());
		int found = 0;
		for (int row = 0; row < source.size(); row++) {
			if (getFinished()) break;
			setValue(row);
			String [] tempString = new String[3];
			String [] tokens = (String []) source.elementAt(row);
			for (int i = 0; i < 3; i++) {
				tempString[i] = tokens[i];
			}
			nvec.addElement(tempString);
			nvec.addElement(new Double(tokens[3]));
			found++;
		}
		return found;
	}
	
		 private void setValue(int j) {
			 final int i = j;
			 Runnable update = new Runnable() {
				 public void run() { loadProgress.setValue(i); }
			 };
			 SwingUtilities.invokeLater(update);
		 }
		 */
		 private void println(String k) {
			 final String s = k;
//			  LogPanel.println(s);
//			  if (progressMonitor != null) progressMonitor.setNote(k);
			  Runnable update = new Runnable() {
				 public void run() { loadProgress.println(s); }
			 };
			 SwingUtilities.invokeLater(update);
		 }

	public static void main(String [] argv) {
		final TVModel model = new TVModel();
		final JFrame frame = new JFrame("Test TVModelLoader");
		final FileSet fileSet = new FileSet(argv[0], "");
		JButton button = new JButton("load " + argv[0]);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.setSource(fileSet);
				TVModelLoader loader = new TVModelLoader(model, frame);
				try {
					loader.loadInto();
				} catch (LoadException ex) {
					System.out.println(ex);
					ex.printStackTrace();
				}
			}
		});
		frame.getContentPane().add(new JLabel("Test TVModelLoader"));
		frame.getContentPane().add(button);

		frame.pack();
		frame.setVisible(true);
		frame.addWindowListener( new WindowAdapter() {
			public void windowClosing(WindowEvent windowEvent) {
				System.exit(0);
			}
		});
	}
	/**
	 * these internal variables are used to keep track of the 
	 * state of the tvmodel as it is being loaded.
	 */ 
	private int nGene, nExpr;
	// cols to skip over before arrays begin...
	private int nGenePrefix;
	// how many rows of annotation?
	private int nExprPrefix;
}

