/* BEGIN_HEADER                                              Java TreeView
 *
 * $Author: alokito $
 * $RCSfile: FileScanner.java,v $
 * $Revision: 1.6 $
 * $Date: 2004/12/21 03:28:14 $
 * $Name:  $
 *
 * This file is part of Java TreeView
 * Copyright (C) 2001-2003 Alok Saldanha, All Rights Reserved. Modified by Alex Segal 2004/08/13. Modifications Copyright (C) Lawrence Berkeley Lab.
 *
 * This software is provided under the GNU GPL Version 2. In particular, 
 *
 * 1) If you modify a source file, make a comment in it containing your name and the date.
 * 2) If you distribute a modified version, you must do it under the GPL 2.
 * 3) Developers are encouraged but not required to notify the Java TreeView maintainers at alok@genome.stanford.edu when they make a useful addition. It would be nice if significant contributions could be merged into the main distribution.
 *
 * A full copy of the license can be found in gpl.txt or online at
 * http://www.gnu.org/licenses/gpl.txt
 *
 * END_HEADER 
 */
package edu.stanford.genetics.treeview;


import java.io.*;

/**
 *  This class implements a scanner which calculates 
 * <ul>
 * <li> how many lines are in a filew </li>
 * <li> the number of tabs in a line </li>
 * </ul>
 *
 * It will throw an exception if there are
 *  not the same number of tabs in every line
 *
 * @author     Alok Saldanha <alok@genome.stanford.edu>
 * @version $Revision: 1.6 $ $Date: 2004/12/21 03:28:14 $
 */

public class FileScanner {
	private int nlines;
	private int ntabs;
	private int eWeightLine  = 0;

	protected Reader st;


	/**
	 *  The main program for the FileScanner class
	 *
	 * @param  argv  The command line arguments
	 */
	public static void main(String[] argv) {
		if (argv.length == 0) {
			System.out.println("Usage:");
			System.out.println("  java FileScanner <file>");
		} else {
			System.out.println("Counting " + argv[0]);

		FileScanner fs;
			try {
				fs = new FileScanner(argv[0]);
				System.out.println(" Lines " + fs.lines());
				System.out.println(" Tabs " + fs.tabs());
				System.out.println(" Eweight Line " + fs.eWeightLine());
			} catch (IOException e) {
				System.out.println("Caught IOException: " + e.getMessage());
			}
		}
	}


	/**
	 *
	 * @return    Number of lines found during parsing
	 */
	public int lines() {
		return nlines;
	}


	/**
	 * @return    Number of tabs found during parsing
	 */
	public int tabs() {
		return ntabs;
	}


	/**
	 *  Constructor for the FileScanner object
	 *
	 * @param  file             File to scan
	 * @exception  IOException  I don't throw this, look in BufferedReader
	 */
	public FileScanner(String file) throws IOException {
		st = new BufferedReader(new FileReader(file));
		ntabs = 0;
		nlines = 0;
		count();
	}
	/**
	* this is purely for the benefit of subclasses.
	*/
	protected FileScanner() {
	}

	/**
	 *
	 * @return    line number of the eWeightLine, if any
	 */
	public int eWeightLine() {
		return eWeightLine;
	}


	/**
	 *  Start counting
	 *
	 * @exception  IOException  Thrown by BufferedReader
	 */
	protected void count() throws IOException {
	int ch           = st.read();

		while ((ch != '\n') &&
				(ch != '\r') &&
				(ch != -1)) {
			if (ch == '\t') {
				ntabs++;
			}
			ch = st.read();
		}

	/*
	 *  simple fsm states:
	 *  0 nothing found yet
	 *  1-6 GWEIGHT
	 *  7 start of line is not GWEIGHT
	 *  8 GWEIGHT found, game over
	 */
	char[] required  = new char[]{'E', 'W', 'E', 'I', 'G', 'H', 'T'};
	int state        = 0;
	boolean lastSep = false;
	// int sep          = ch; nice idea, but doesn't work on windows....
	while (ch != -1) {
	  if ((ch == '\n') || (ch == '\r')){
		if (lastSep == false) {
		  nlines++;
		  if (state < 8) {
			// reset state on newline
			state = 0;
		  }
		  lastSep = true;
		}
	  } else {
		lastSep = false;
		if (state < 7) {
		  if (ch == required[state]) {
			state++;
			// System.out.println("ch " + (char) ch + " matched required line " + nlines );
		  } else {
			// System.out.println("ch " + (char) ch + " did not match required " + required[state] + ", line " + nlines);
			state = 7;
		  }
		  if (state == 6) {
			  if (eWeightLine == 0) {
				  eWeightLine = nlines;
			  }
		  }
		}
	  }
	  ch = st.read();
	}
  }

}

