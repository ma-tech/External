/* BEGIN_HEADER                                              Java TreeView
 *
 * $Author: alokito $
 * $RCSfile: UrlScanner.java,v $
 * $Revision: 1.4 $
 * $Date: 2004/12/21 03:28:14 $
 * $Name:  $
 *
 * This file is part of Java TreeView
 * Copyright (C) 2001-2003 Alok Saldanha, All Rights Reserved. Modified by Alex Segal 2004/08/13. Modifications Copyright (C) Lawrence Berkeley Lab.
 *
 * This software is provided under the GNU GPL Version 2. In particular, 
 *
 * 1) If you modify a source file, make a comment in it containing your name and the date.
 * 2) If you distribute a modified version, you must do it under the GPL 2.
 * 3) Developers are encouraged but not required to notify the Java TreeView maintainers at alok@genome.stanford.edu when they make a useful addition. It would be nice if significant contributions could be merged into the main distribution.
 *
 * A full copy of the license can be found in gpl.txt or online at
 * http://www.gnu.org/licenses/gpl.txt
 *
 * END_HEADER 
 */
package edu.stanford.genetics.treeview;


import java.io.*;

/**
 * Scan a resource to find the number of tabs and newlines in it.
 *  This class implements a scanner which calculates 
 * <ul>
 * <li> how many lines are in a url resource </li>
 * <li> the number of tabs in the first non-whitespace line </li>
 * </ul>
 *
 * It will throw an exception if there are
 *  not the same number of tabs in every line
 *
 * As with the FileScanner, it does the scan when it is constructed.
 *
 * @author     Alok Saldanha <alok@genome.stanford.edu>
 * @version $Revision: 1.4 $ $Date: 2004/12/21 03:28:14 $
 */

public class UrlScanner extends FileScanner {

	/**
	 *  A test program.
	 *
	 * @param  argv  Call with a valid url.
	 */
	public static void main(String[] argv) {
		if (argv.length == 0) {
			System.out.println("Usage:");
			System.out.println("  java UrlScanner <url>");
		} else {
			System.out.println("Counting " + argv[0]);

		FileScanner fs;
			try {
				fs = new FileScanner(argv[0]);
				System.out.println(" Lines " + fs.lines());
				System.out.println(" Tabs " + fs.tabs());
				System.out.println(" Eweight Line " + fs.eWeightLine());
			} catch (IOException e) {
				System.out.println("Caught IOException: " + e.getMessage());
			}
		}
	}

	/**
	 *  Constructor for the UrlScanner object
	 *
	 * @param  urlString             Url to scan
	 * @exception  IOException  I don't throw this, look in <code> BufferedReader </code>
	 */
	 public UrlScanner(String urlString) throws IOException {
		 super();
		 java.net.URL url = new java.net.URL(urlString);
		 st = new InputStreamReader(url.openStream());
		 count();
	 }
}

