/* BEGIN_HEADER                                              Java TreeView
 *
 * $Author: alokito $
 * $RCSfile: TreeView.java,v $
 * $Revision: 1.8 $
 * $Date: 2004/12/21 03:28:16 $
 * $Name:  $
 *
 * This file is part of Java TreeView
 * Copyright (C) 2001-2003 Alok Saldanha, All Rights Reserved. Modified by Alex Segal 2004/08/13. Modifications Copyright (C) Lawrence Berkeley Lab.
 *
 * This software is provided under the GNU GPL Version 2. In particular, 
 *
 * 1) If you modify a source file, make a comment in it containing your name and the date.
 * 2) If you distribute a modified version, you must do it under the GPL 2.
 * 3) Developers are encouraged but not required to notify the Java TreeView maintainers at alok@genome.stanford.edu when they make a useful addition. It would be nice if significant contributions could be merged into the main distribution.
 *
 * A full copy of the license can be found in gpl.txt or online at
 * http://www.gnu.org/licenses/gpl.txt
 *
 * END_HEADER */

import java.applet.Applet;

import edu.stanford.genetics.treeview.app.TreeViewApp;


/**
 *  This class is a hollow shell that runs the package-scoped app.
 *
 *  It also implements the applet portion...
 */
public class TreeView  extends Applet
{
	public static void main(String astring[])
	{
		TreeViewApp.main(astring);
	}
	
	/* Applet specific code follows... */
		/**  start method for running as applet */
		/*
	public void start() {
		super.start();
		
		
		TextArea sarcastic  = new TextArea("This text is to let you know the applet is running.\n" +
				"I lack the time and interest to come up with\n" + " a layout for Java TreeView\n" +
				"within the applet window, so I've decided to\n" + " just pop up an external window.");
		add(sarcastic);
		TreeViewApp app = new TreeViewApp(generateGlobalConfig());
		String initialFile         = getParameter("initialCdt");
//		JOptionPane.showMessageDialog(this, "got initialCdt " + initialFile);
		try {
			if (initialFile == null) {
				app.openApplet();
			} else {
				app.openApplet(new FileSet(initialFile,""));
			}
		} catch (LoadException e) {
			JPanel temp = new JPanel();
			temp.setLayout(new BoxLayout(temp, BoxLayout.Y_AXIS));
			temp.add(new JLabel("Problems opening url " + initialFile));
			temp.add(new JLabel("" + e));
			JOptionPane.showMessageDialog(this, temp);
		}
	}
*/
	/**
	* This subroutine generates a globalconfig to be used in applet mode.
	* <p>
	* It first tries to load getCodeBase() + "globalConfig.xml", and if that falls through for
	* any reason it defaults to a generic XmlConfig.
	*/
/*
	private XmlConfig generateGlobalConfig() {
		XmlConfig globalConfig = null;
		String url          = getParameter("globalConfig");
		if (url != null) {
			try {

				String xmlText     = "";
				java.net.URL urlO  = new URL(url);
				Reader st          = new InputStreamReader(urlO.openStream());
				int ch             = st.read();
				while (ch != -1) {
					char[] cbuf  = new char[1];
					cbuf[0] = (char) ch;
					xmlText = xmlText + new String(cbuf);
					ch = st.read();
				}
				// urlAccessViolation(xmlText);
				globalConfig = new XmlConfig(new java.net.URL(url), xmlText, "ProgramConfig");
				//     urlAccessViolation(globalConfig.toString());
			} catch (java.net.MalformedURLException e) {
			} catch (java.security.AccessControlException sec) {
				urlAccessViolation(url + "\n" + sec);
			} catch (Exception ex) {
				urlAccessViolation(ex.toString());
			}

		}
		if (globalConfig == null) {
			globalConfig = new XmlConfig((java.net.URL) null, null, "ProgramConfig");
		}
		return globalConfig;
	}
*/	
	/**
	 *  Called when a url is improperly accessed. Pops up a window the hard way.
	 *
	 * @param  url  url which we do not have authorization for.
	 */
	 /*
	public void urlAccessViolation(String url) {
		TextArea mp      = new TextArea("Bad URL\n" +
				"There was a security exception accessing the url\n" + url +
				"\nremember, applets can only load urls from the same server");
		final Frame top  = new Frame("Bad URL");
		top.addWindowListener(
			new WindowAdapter() {

				public void windowClosing(WindowEvent windowEvent) {
					top.dispose();
				}
			});

		top.add(mp);
		top.pack();
		top.show();
	}
*/

}

