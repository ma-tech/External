javac -classpath ../java/GIFEncoder.jar:../java/nanoxml-2.1.jar:. *.java
# javac -classpath ../java/GIFEncoder.jar:../java/nanoxml-2.1.jar:. ColorPresetEditor.java ColorSet.java

 java -classpath ../java/GIFEncoder.jar:../java/nanoxml-2.1.jar:. StatView

# jar cmf MANIFEST.MF ../public_html/TreeView/examples/TreeView.jar *.class
# jar cmf MANIFEST.MF ~/examples/TreeView.jar *.class

# java -classpath ../java/GIFEncoder.jar:../java/nanoxml-2.1.jar:. ExportPanel ../../aad.cdt 


# java  -classpath ../java/GIFEncoder.jar:../java/nanoxml-2.1.jar:. TreeView

# jar cf ../public_html/files/TreeView.jar *.class

# jar cmf MANIFEST.MF ../../TreeView.jar *.class *.java

